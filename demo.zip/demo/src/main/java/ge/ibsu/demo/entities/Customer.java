package ge.ibsu.demo.entities;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "customer")
public class Customer {
    @Id
    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "create_date")
    private Date createDate;

    @Column(name = "active")
    private Integer active;

    @ManyToOne(fetch = FetchType.LAZY)
    private Address address;

    public Long getCustomerId(){
        return customerId;
    }

}
